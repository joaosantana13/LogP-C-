﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SemiCalculadora
{
    public partial class FrmSemicalc : Form
    {
        public FrmSemicalc()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Variaveis
            int numInt = int.Parse(txtInteiro.Text);
            float numDecimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Soma
            resultado = numInt + numDecimal;
            MessageBox.Show("Soma:" + resultado);

            //Subtracao
            resultado = numInt - numDecimal;
            MessageBox.Show("Subtração:" + resultado);

            //Divisao
            resultado = numInt / numDecimal;
            MessageBox.Show("Divisão:" + resultado);

            //Multiplicacao
            resultado = numInt * numDecimal;
            MessageBox.Show("Multiplicação:" + resultado);

        }
    }
}
