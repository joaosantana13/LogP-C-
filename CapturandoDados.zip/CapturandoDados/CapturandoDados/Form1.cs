﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapturandoDados
{
    public partial class FrmDados : Form
    {
        public FrmDados()
        {
            InitializeComponent();
        }

        private void lblBooleano_Click(object sender, EventArgs e)
        {

        }

        private void btnEntrar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Voce enviou seu formulario.");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Voce limpou os campos.");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Digite seu numero inteiro.");
        }

        private void txtTexto_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Digite seu texto.");
        }

        private void txtBooleano_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Digite seu numero Booleano.");
        }

        private void txtDecimal_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Digite seu numero decimal.");
        }

        private void FrmDados_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Formulario Aberto.");
        }
    }
}
